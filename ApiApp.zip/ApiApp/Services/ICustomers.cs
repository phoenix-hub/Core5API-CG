﻿using ApiApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ApiApp.Services
{
    public interface ICustomers
    {
        List<Customer> GetCustomers();
        List<Customer> GetCustomersByCategory(string Category);
    }
}

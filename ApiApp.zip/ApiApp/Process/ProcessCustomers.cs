﻿using ApiApp.Services;
using ApiApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ApiApp.CustomerContext;

namespace ApiApp.Services
{
    public class ProcessCustomers : ICustomers
    {
        private readonly CustContext _custContext;
        public ProcessCustomers(CustContext custContext)
        {
            _custContext = custContext;
        }
        public List<Customer> GetCustomers()
        {
            try
            {
                var lstCustomer = _custContext.Customers.ToList();

                return lstCustomer;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Customer> GetCustomersByCategory(string Category)
        {
            return _custContext.Customers.Where(x => x.CustomerCategoryName == Category).ToList();
        }
    }
}
